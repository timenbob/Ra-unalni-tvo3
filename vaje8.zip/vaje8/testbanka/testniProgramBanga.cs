﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testbanka
{
    internal class testniProgramBanga
    {
        static void Main(string[] args)
        {
            BancniRacun mojRacun = new BancniRacun;
        }
    }
}
